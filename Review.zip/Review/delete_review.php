<?php
include ('config.php');
include_once('blueprint.php');

// Check if 'id' is passed in the POST request
if (isset($_POST['id'])) {
    // Sanitize the review ID to prevent SQL injection
    $reviewID = intval($_POST['id']);

    // Prepare the SQL delete query
    $query = "DELETE FROM reviews WHERE reviewID = ?";
    $stmt = $conn->prepare($query);

    // Bind the review ID as an integer parameter
    $stmt->bind_param('i', $reviewID);

    // Execute the query
    if ($stmt->execute()) {
        // If successful, return a success response
        echo json_encode(['status' => 'success']);
    } else {
        // If there is an error during deletion, return an error message
        echo json_encode(['status' => 'error', 'message' => 'Failed to delete review.']);
    }

    // Close the statement
    $stmt->close();
} else {
    // If no ID is provided, return an error
    echo json_encode(['status' => 'error', 'message' => 'No review ID provided.']);
}

// Close the database connection
$conn->close();
?>
