<?php
$host = "localhost";  // database host
$db_user = "root";     // database username
$db_password = "";     // database password
$db_name = "mpsm_ecommerce"; // database name

// Create a database connection
$conn = mysqli_connect($host, $db_user, $db_password, $db_name);

// Check if the connection is successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}else{
    echo "Connection successful!!!";
}
?>
